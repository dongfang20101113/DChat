# dchat Linux 客户端 / 服务端（预编译，免编译）

架构：**x86_64 (amd64)**。对应源码版本 `48e3130`，仓库
https://github.com/dongfang20101113/DChat

## 直接运行

```bash
tar -xzf dchat-linux-x86_64.tar.gz
cd dchat-linux-x86_64
chmod +x dchat_client dchat_server        # 从 Windows 解压过来的话必须做这一步

# 连服务器（注册新账号）
./dchat_client --host 服务器地址 --port 5555 --user 你的名字 --pass 你的密码 --register

# 以后登录（去掉 --register 就是登录）
./dchat_client --host 服务器地址 --port 5555 --user 你的名字 --pass 你的密码

# 自己开一个服务器
./dchat_server --port 5555
```

## 两个版本，怎么选

| 文件 | 依赖 | 适用 |
| --- | --- | --- |
| `dchat_client` / `dchat_server` | **零依赖**（全静态，一个 .so 都不要） | 任何 x86_64 Linux，直接跑 |
| `extra/dchat_client_glibc` 等 | 只要系统 glibc ≥ 2.38 | Ubuntu 23.10+ / Debian 13+ |

**默认用不带后缀的那两个。** 它们的 OpenSSL、libstdc++、libgcc 全部静态链进去了，
`ldd` 显示"not a dynamic executable"，拷到别的机器上不需要装任何东西。

`extra/` 里的版本体积小 5 倍，但要求目标机 glibc ≥ 2.38
（Ubuntu 24.04 是 2.39 可以、22.04 是 2.35 不行、Debian 12 是 2.36 不行）。
它的好处是 DNS 走系统 NSS，行为最标准。

两个版本都实测过：本机服务端 + 本机客户端，主机名和 IP 两种地址都能完成
加密握手、注册、收发消息。

## 客户端怎么用

连上之后是终端聊天界面：消息往上滚，输入行固定在下面。

| 操作 | 说明 |
| --- | --- |
| 直接输入 + 回车 | 发言 |
| `Tab` | 补全指令和在线昵称（多候选连按会循环） |
| `↑` / `↓` | 翻输入历史 |
| `Ctrl+U` | 清空当前输入 |
| `Ctrl+C` / `/quit` | 退出 |

本地指令（不会发给服务器）：

| 指令 | 说明 |
| --- | --- |
| `/send <文件路径>` | 上传文件（上限 64 MB），成功后显示服务器分配的附件 id |
| `/get <附件 id>` | 下载附件到 `./dchat-downloads/`（重名自动加序号） |
| `/voice [秒数]` | 录音，再敲一次 `/voice` 停下并发送 |
| `/play <附件 id>` | 播放音频附件（语音会自动下载） |
| `/chatcolor on\|off` | 本机彩色聊天开关 |
| `/clear` | 清屏 |
| `/help` | 列出所有服务器指令 |
| `/quit` | 退出 |

其余 `/ban`、`/kick`、`/say` 之类的指令原样发给服务器。

批处理模式（脚本用，也方便自测）：

```bash
./dchat_client --user 名字 --pass 密码 --register \
    --send "你好" --expect-any "你好" --timeout 8
```
退出码：0 成功、2 连不上或发不出、3 超时、4 服务器指纹变了被中止。

## 彩色文字

| 写法 | 效果 |
| --- | --- |
| `&0` ~ `&f` | 十六个快捷色（和 Windows、安卓端颜色表完全一致） |
| `&#rrggbb` | 真彩色，例如 `&#ff8800` 橙色 |
| `&&` | 一个字面量 `&` |

终端需要支持真彩色（Windows Terminal、GNOME Terminal、konsole、
iTerm2 都支持）。服务器用 `chatcolor=0` 关掉彩色聊天时，色码会原样显示而不是被吃掉。

## 语音需要额外装一个包

录音和播放是调 `arecord` / `aplay`，不在二进制里：

```bash
sudo apt-get install -y alsa-utils      # Debian / Ubuntu
sudo dnf install -y alsa-utils          # Fedora / RHEL
```

没装的话按 `/voice` 会明确提示"找不到 arecord"，不会崩。没有声卡的机器
（容器、云服务器）也会明确提示"没有声卡设备"。

格式和 Windows、安卓端完全一致：16 kHz / 单声道 / 16 位 WAV，上限约 64 秒。

## 安全说明（请读一眼）

第一次连一台服务器会记住它的指纹，存到当前目录的 `dchat-known-servers.txt`。
以后每次连都会比对，**指纹变了会明确警告并中止**。这挡的是"有人偷偷换了服务器密钥
做中间人"。确认是管理员换过密钥，才加 `--insecure-ok` 继续。

**换目录运行会重新"第一次信任"**，所以建议固定在一个目录里用。

## 已知限制

- **光标编辑只在行尾**：左右方向键不动光标，退格删末尾。终端里光标按显示格算、
  输入串按 UTF-8 字节算，中文一个字占两格但三字节，行内编辑要两者都算对才不歪，
  这一版先没做。
- **没有图形界面**：这是终端客户端。
- 全静态版虽然实测主机名解析正常，但 glibc 对静态链接下的 `getaddrinfo` 有官方
  警告。如果遇到主机名解析异常，改用 `extra/` 里的 glibc 动态版即可。
- 预编译包只做了 **x86_64**。ARM64 需要自己编译（见仓库 linux/README.md）。